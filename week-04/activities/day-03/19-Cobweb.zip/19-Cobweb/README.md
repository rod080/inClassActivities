# Cobweb

## File

* [`cobweb-starter`](Unsolved/cobweb-starter.html)

## Instructions

* Create the missing the code such that you can retrieve the requested item from the `theCobWeb` object.

* **NOTE:** This exercise is actually very relevant to work as a web developer, as data is often relayed across websites in the form of deeply nested JavaScript objects like this one.

* **BONUS:** If you finish early, begin pondering the bonus item. This is a **very** challenging exercise. It's impossible to complete in the allotted time. If you're feeling valiant - complete it outside of class and come back to instructors/TAs to go over it. This will arm you for difficult interview questions in the future.
