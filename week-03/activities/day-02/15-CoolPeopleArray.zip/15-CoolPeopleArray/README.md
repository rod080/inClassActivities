### File

* [`array-logs-unsolved`](Unsolved/array-logs-unsolved.html)

### Instructions

* Follow the instructions provided in the file to `console.log` each of the names in the `coolPeople` variable.

* **HINT:** You should be repeating the same line 6 times.
