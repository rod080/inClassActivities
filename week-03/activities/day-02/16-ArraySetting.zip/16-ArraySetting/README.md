### File

* [`array-setting-unsolved`](Unsolved/array-setting-unsolved.html)

### Instructions

* Follow the instructions in the file above to convert each item in the array to lower case.

* Make sure to only add in lines of code where instructed.

* **HINT:** You will need to use the `.toLowerCase()` method. Research if you don't remember how to use it.

* Be prepared to share when time is up.
