### File

* [`js-dissect-unsolved`](Unsolved/js-dissect-unsolved.html)

### Instructions

* Take a few minutes to quickly look through the above file. With a partner, discuss what you expect to happen when the code is run.

* Prepare to share your thoughts with the class.
